        # document_interaction_assistant

        An AI agent for: This AI agent is a document interaction assistant built using LangGraph and Flask, designed to provide context-grounded answers from various uploaded file types like PDFs, Word documents, and spreadsheets. The data flow begins with the processing of uploaded files into a FAISS vector store using HuggingFace embeddings, which is then managed by a StateGraph workflow that handles the retrieval and generation phases. When a user sends a message, the graph first enters the retrieve node to fetch the top five relevant document chunks from the vector store; if documents are successfully retrieved, it transitions to the generate node where the content is passed along with a detailed system prompt to the OpenRouter API (utilizing Claude-3-Haiku) to produce a structured, Markdown-formatted response. The workflow maintains state through an AgentState object that tracks the user input, chat history, and retrieved context, ensuring the final output is accurate, professional, and directly informed by the user's specific document data.

        ## Tools
        - `process_uploaded_files`
- `retrieve_relevant_chunks`
- `generate_structured_response`

        ## Usage
        ```bash
        cd output/document_interaction_assistant
        export OPENAI_API_KEY=your_key_here
        python run.py "Your query here"
        ```

        ## Fingerprint
        `N/A`
