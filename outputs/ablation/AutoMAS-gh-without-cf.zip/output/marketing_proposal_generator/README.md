        # marketing_proposal_generator

        An AI agent for: This BOT is designed to automate the creation of structured marketing proposals by synthesizing user-defined campaign parameters and optional document data. The agent's purpose is to act as a specialized marketing strategist that processes inputs—including product name, description, target audience, location, and budget—alongside text extracted from uploaded PDF briefs via the fitz library. The data flow begins with the Streamlit interface capturing these variables and validating them to ensure all required fields are populated before triggering the generation process. Once activated, the campaign request is formatted into a comprehensive prompt and passed to the run_chatbot function, which orchestrates the interaction with the underlying generative AI model to produce a final, tailored campaign proposal. The resulting output is then rendered back to the user within a persistent UI expander, providing a seamless transition from raw data input to a polished marketing strategy.

        ## Tools
        - `pdf_text_extractor`
- `run_chatbot`

        ## Usage
        ```bash
        cd output/marketing_proposal_generator
        export OPENAI_API_KEY=your_key_here
        python run.py "Your query here"
        ```

        ## Fingerprint
        `N/A`
