        # deep_research_assistant

        An AI agent for: This agent is designed as a deep research assistant that automates the process of gathering information and generating comprehensive reports through a structured multi-node workflow. The data flow begins at the CLARIFY_WITH_USER node, which evaluates if additional input is required; if so, the graph can terminate or proceed to WRITE_RESEARCH_BRIEF to establish the study's parameters. Once a brief is defined, the state moves to the SUPERVISOR_SUBGRAPH, which orchestrates specialized multi-agent research to collect relevant notes and findings. These findings are then passed to the FINAL_REPORT_GENERATION node, where a large language model (GPT-4.1) synthesizes the gathered notes, research brief, and current date into a formatted final report. The process concludes by delivering the report and updating the global state before reaching the END node, ensuring a linear and verifiable transition from initial user inquiry to a finalized research document.

        ## Tools
        - `web_search`
- `database_query`
- `note_aggregation`
- `final_report_synthesis`

        ## Usage
        ```bash
        cd output/deep_research_assistant
        export OPENAI_API_KEY=your_key_here
        python run.py "Your query here"
        ```

        ## Fingerprint
        `N/A`
