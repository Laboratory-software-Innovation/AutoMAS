        # travel_assistant_supervisor

        An AI agent for: This agent is designed as a multi-agent travel assistant supervisor that coordinates specialized tasks between flight and hotel booking agents. The data flow begins at the supervisor node, which uses an LLM with structured output to analyze user intent and route the conversation to either the flight_agent or the hotel_agent subgraph based on the request. The flight_agent node processes flight-related queries and returns results directly to the supervisor, while the hotel_agent subgraph manages hotel bookings, passing its output through a process_output node to ensure message formatting is compatible with the supervisor's state before returning control. This cyclical process continues, with the supervisor maintaining the conversation state and deciding the next action, until it determines the user's request is fulfilled and triggers the FINISH state to end the workflow.

        ## Tools
        - `analyze_user_intent`
- `flight_search_tool`
- `flight_booking_tool`
- `hotel_search_tool`
- `hotel_booking_tool`
- `process_output`

        ## Usage
        ```bash
        cd output/travel_assistant_supervisor
        export OPENAI_API_KEY=your_key_here
        python run.py "Your query here"
        ```

        ## Fingerprint
        `N/A`
