        # default_agent

        An AI agent for: 

        ## Tools
        - `fetch_web_data`
- `process_data`
- `generate_output`

        ## Usage
        ```bash
        cd output/default_agent
        export OPENAI_API_KEY=your_key_here
        python run.py "Your query here"
        ```

        ## Fingerprint
        `N/A`
