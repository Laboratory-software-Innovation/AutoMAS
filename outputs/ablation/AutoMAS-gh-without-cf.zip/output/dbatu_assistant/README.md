        # dbatu_assistant

        An AI agent for: This ReAct agent is designed as an official multilingual AI assistant for Dr. Babasaheb Ambedkar Technological University (DBATU), intended to provide accurate information regarding university policies, admissions, and campus life. The data flow begins with a user query that is processed through a ReAct logic loop, where the agent first prioritizes the DBATUInternalKnowledgeSearch tool to query a local FAISS vector database containing internal university documents. If the internal search is insufficient and the query remains university-relevant, the agent flows to the WebSearch tool powered by Serper API for broader context, while strictly declining non-DBATU questions to maintain domain relevance. The agent utilizes a ConversationBufferMemory to maintain context across turns and strictly outputs its reasoning and final answers in a structured ReAct format (Thought/Action/Observation), ensuring all responses are polite, conversational, and supported by official links or contact directives.

        ## Tools
        - `dbatu_internal_knowledge_search`
- `web_search`

        ## Usage
        ```bash
        cd output/dbatu_assistant
        export OPENAI_API_KEY=your_key_here
        python run.py "Your query here"
        ```

        ## Fingerprint
        `N/A`
