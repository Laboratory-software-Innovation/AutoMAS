        # finance_gpt

        An AI agent for: This agent, named Finance GPT, is designed as a specialized AI financial assistant that provides insights on personal finance management, including budgeting, debt strategies, and real-time market analysis. The agent utilizes a StateGraph architecture where the data flow begins at the home node, which invokes an Azure OpenAI LLM configured with a detailed system prompt and a set of financial tools. When a user makes a request, the LLM determines if external data is required; if so, the graph routes through a conditional edge to the tools node to execute functions such as getStockPrice, getStockData, getStockRecommendation, getCompanyNews, or getCompanyEarnings via the Finnhub API. Once the tool results are integrated into the message state, the flow returns to the home node for the LLM to generate a final, markdown-formatted response, ensuring a continuous loop of information gathering and analysis until the user's query is fully addressed.

        ## Tools
        - `get_stock_price`
- `get_stock_data`
- `get_stock_recommendation`
- `get_company_news`
- `get_company_earnings`

        ## Usage
        ```bash
        cd output/finance_gpt
        export OPENAI_API_KEY=your_key_here
        python run.py "Your query here"
        ```

        ## Fingerprint
        `N/A`
