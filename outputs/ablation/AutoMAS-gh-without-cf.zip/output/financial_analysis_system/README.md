        # financial_analysis_system

        An AI agent for: This agent is designed as a multi-agent financial analysis system that synthesizes specialized market research into a professional report. The workflow is orchestrated through a StateGraph using a MultiAgentState to manage data across four distinct nodes: news_analyst, technical_analyst, financial_analyst, and report_writer. The data flow begins with the news_analyst, which scours the web for sentiment and news, then passes the state to the technical_analyst for chart and trend analysis, followed by the financial_analyst to evaluate financial statements. Each specialist node utilizes a factory function to invoke a tool-enabled LLM that populates its respective field in the state. Finally, the report_writer node acts as a manager, ingesting the accumulated specialist reports to generate a cohesive, professional market analysis featuring an introduction and conclusion, before reaching the graph's end point.

        ## Tools
        - `web_scraper`
- `sentiment_analyzer`
- `chart_generator`
- `trend_analyzer`
- `financial_statement_evaluator`

        ## Usage
        ```bash
        cd output/financial_analysis_system
        export OPENAI_API_KEY=your_key_here
        python run.py "Your query here"
        ```

        ## Fingerprint
        `N/A`
