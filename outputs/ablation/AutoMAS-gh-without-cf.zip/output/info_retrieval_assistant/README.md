        # info_retrieval_assistant

        An AI agent for: This agent is designed as a versatile information retrieval assistant that utilizes a functional tool-calling loop to answer user queries by accessing Wikipedia, OpenWeatherMap, and Tavily Search. The data flow begins at the agent node, where a GPT-4o-mini model processes the user's input and chat history to determine if a tool call is required or if a final response can be generated. If the agent identifies a need for external information, the graph transitions to the action node via a conditional edge, where the ToolNode executes the specified tool—such as Wikipedia for encyclopedic data or WeatherTool for location-based updates—and feeds the results back into the intermediate_steps of the AgentState. This cycle continues iteratively, with the agent reflecting on tool outputs to refine its reasoning, until it produces an AgentFinish signal, signifying the completion of the task and the delivery of the final synthesized answer.

        ## Tools
        - `fetch_wikipedia_data`
- `fetch_weather_data`
- `perform_tavily_search`

        ## Usage
        ```bash
        cd output/info_retrieval_assistant
        export OPENAI_API_KEY=your_key_here
        python run.py "Your query here"
        ```

        ## Fingerprint
        `N/A`
