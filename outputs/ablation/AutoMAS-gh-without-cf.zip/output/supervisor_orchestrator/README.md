        # supervisor_orchestrator

        An AI agent for: This supervisor workflow is designed to manage a multi-agent system that coordinates specialized tasks between a research expert and a math expert to answer complex queries. The agent's core intent is to act as a central orchestrator that intelligently routes user requests based on the nature of the query: historical or current factual data is directed to the research_expert, which utilizes a web search tool, while mathematical calculations are delegated to the math_expert, which has access to addition and multiplication tools. The data flow begins with the supervisor receiving a user message, analyzing the content to determine the required expertise, and then dispatching the task to the appropriate specialized ReAct agent. Once the specialized agent completes its task—such as retrieving specific employee headcounts or performing arithmetic—the information is passed back through the supervisor to compile a final, comprehensive response for the user.

        ## Tools
        - `web_search_tool`
- `addition_tool`
- `multiplication_tool`

        ## Usage
        ```bash
        cd output/supervisor_orchestrator
        export OPENAI_API_KEY=your_key_here
        python run.py "Your query here"
        ```

        ## Fingerprint
        `N/A`
