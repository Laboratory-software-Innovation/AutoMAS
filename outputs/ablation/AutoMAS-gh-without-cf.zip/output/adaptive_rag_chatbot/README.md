        # adaptive_rag_chatbot

        An AI agent for: This Adaptive RAG ChatBot is designed as an intelligent document-based assistant that dynamically routes queries between a local vector store and web search to provide accurate, grounded answers from uploaded PDFs. The data flow is governed by a StateGraph that starts with a route_question node, which classifies the user input to either retrieve relevant chunks from a Chroma database for specialized topics or trigger a web_search using the Tavily API for general knowledge. Once documents are gathered, they pass through a grade_documents node to filter out irrelevant information, potentially triggering a transform_query node to refine the user's question if no initial matches are found. The process then moves to the generate node, where the LLM produces a response that is subsequently scrutinized by a grade_generation_v_documents_and_question node to check for hallucinations and ensure the answer directly addresses the user's query. The graph concludes at the END state only when the generation is verified as grounded and useful, otherwise looping back for query transformation or re-generation to ensure high-fidelity output.

        ## Tools
        - `chroma_db_search`
- `tavily_web_search`
- `grade_documents`
- `transform_query`
- `grade_generation_v_documents_and_question`

        ## Usage
        ```bash
        cd output/adaptive_rag_chatbot
        export OPENAI_API_KEY=your_key_here
        python run.py "Your query here"
        ```

        ## Fingerprint
        `N/A`
