        # bread_finder

        An AI agent for: This agent, titled "Bread Finder," is designed as a personal job hunt assistant that automates the management of employment opportunities by interacting with a user's Gmail account and local files. The data flow begins at the agent node, where a ChatOpenAI model processes the conversation state to either prompt the user for Gmail credentials or determine the next step in the job search. When the model triggers a tool call, the graph transitions to the tools node to execute specific functions such as connecting to or disconnecting from Gmail, searching for job-related emails, drafting messages, or parsing resume files (PDF/TXT) from a local desktop directory. After tool execution, a conditional edge evaluates the results: if the output indicates a disconnection or exit, the graph reaches the END state; otherwise, it loops back to the agent node to continue the interactive session, maintaining a persistent message history within the AgentState to track the ongoing recruitment workflow.

        ## Tools
        - `connect_gmail`
- `disconnect_gmail`
- `search_job_emails`
- `parse_resume_files`
- `draft_email_message`

        ## Usage
        ```bash
        cd output/bread_finder
        export OPENAI_API_KEY=your_key_here
        python run.py "Your query here"
        ```

        ## Fingerprint
        `N/A`
