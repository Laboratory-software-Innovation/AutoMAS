        # hedge_fund_simulation

        An AI agent for: This AI-powered hedge fund agent is designed as a multi-agent system to simulate professional investment decision-making for educational purposes. The system’s core intent is to synthesize diverse investment philosophies—ranging from the value-driven approaches of Warren Buffett and Ben Graham to the growth-oriented strategies of Cathie Wood and Phil Fisher—into actionable trading orders. The data flow begins with specialized analysis nodes, including the Valuation, Sentiment, Fundamentals, and Technicals Agents, which process market data to generate preliminary trading signals. These signals are then filtered through a series of persona-based investor agents who evaluate the opportunities based on their specific qualitative and quantitative criteria, such as "scuttlebutt" research or margin of safety. Finally, the information flows to the Risk Manager to establish position limits and the Portfolio Manager, who consolidates all inputs to execute final trading decisions and orders.

        ## Tools
        - `fetch_market_data`
- `valuation_analysis_tool`
- `sentiment_analysis_tool`
- `fundamentals_analysis_tool`
- `technicals_analysis_tool`

        ## Usage
        ```bash
        cd output/hedge_fund_simulation
        export OPENAI_API_KEY=your_key_here
        python run.py "Your query here"
        ```

        ## Fingerprint
        `N/A`
