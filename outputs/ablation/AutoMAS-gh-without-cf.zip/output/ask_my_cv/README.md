        # ask_my_cv

        An AI agent for: This agent is designed as a virtual professional assistant named "Ask my cv," which provides structured and friendly responses about Simone’s professional background by integrating RAG (Retrieval-Augmented Generation) capabilities. The data flow begins at the rewrite_question node, which clarifies user input using conversation history to ensure precise information retrieval. The process then branches into parallel retrieval tasks: get_structered_data executes Cypher queries against a Neo4j knowledge graph, while get_unstructered_data performs hybrid searches on a Neo4j vector index for relevant document snippets. These results are aggregated in the grade_documents_and_get_context node, where the most relevant information is filtered and formatted into a unified context. Finally, the generate_final_answer node uses this context to synthesize a markdown-formatted response, highlighting Simone's skills and achievements, before the send_end node signals the completion of the streaming event-driven cycle.

        ## Tools
        - `execute_cypher_query`
- `hybrid_search_vector_index`
- `aggregate_and_filter_results`
- `generate_markdown_response`

        ## Usage
        ```bash
        cd output/ask_my_cv
        export OPENAI_API_KEY=your_key_here
        python run.py "Your query here"
        ```

        ## Fingerprint
        `N/A`
