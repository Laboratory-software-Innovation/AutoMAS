        # persistent_conversational_assistant

        An AI agent for: This agent is designed as a persistent conversational assistant that leverages the Gemini 2.0 Flash model to interact with users while maintaining long-term memory and session history. The agent's core purpose is to provide contextually aware responses by retrieving or initializing a specific conversation ID for each user and logging all interactions into a SQLite database for auditability. The data flow begins with the get_llm_response function, which verifies the user's conversation status and logs the incoming message before passing the input to a StateGraph. Within the graph, the START node triggers a call_model node that invokes the LLM using a MessagesState schema and a MemorySaver checkpointer to manage thread-based history. Once the model generates a response, the data flows back to be logged as an AI message in the database and is finally returned to the user, ensuring a seamless, stateful dialogue.

        ## Tools
        - `verify_user_conversation_status`
- `log_incoming_message`
- `call_model`
- `log_ai_message`
- `manage_thread_based_history`

        ## Usage
        ```bash
        cd output/persistent_conversational_assistant
        export OPENAI_API_KEY=your_key_here
        python run.py "Your query here"
        ```

        ## Fingerprint
        `N/A`
