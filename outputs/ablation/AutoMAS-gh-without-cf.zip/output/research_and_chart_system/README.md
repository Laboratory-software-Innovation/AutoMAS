        # research_and_chart_system

        An AI agent for: This agent is designed as a collaborative multi-agent system that automates the process of researching information and generating visual charts. The workflow begins at the Researcher node, which utilizes the Tavily tool to gather accurate data and then passes it to the chart_generator node, where a Python REPL tool is used to create visual representations. Information flows through a central router that manages state transitions by identifying tool calls, determining when a "FINAL ANSWER" has been reached to end the process, or facilitating continuous interaction between the Researcher and chart_generator for refined outputs. A dedicated tool_node handles execution for both agents, ensuring that once a tool task is completed, the control and data are routed back to the original sender to maintain a consistent and state-aware development loop.

        ## Tools
        - `tavily`
- `python_repl`

        ## Usage
        ```bash
        cd output/research_and_chart_system
        export OPENAI_API_KEY=your_key_here
        python run.py "Your query here"
        ```

        ## Fingerprint
        `N/A`
