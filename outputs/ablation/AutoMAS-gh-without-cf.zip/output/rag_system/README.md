        # rag_system

        An AI agent for: This agent is designed as a robust retrieval-augmented generation (RAG) system that dynamically routes user queries between local knowledge and web search to ensure accurate and grounded answers. The data flow begins at a conditional entry point where a router determines whether to retrieve information from a vector store or proceed directly to a web search. If retrieval is chosen, the agent moves to a grading node to evaluate document relevance; if documents are insufficient, it triggers a web search, otherwise, it proceeds to generation. Following the generation phase, the agent employs a dual-validation process using hallucination and answer graders to ensure the output is supported by the retrieved context and addresses the user's question. If the generation is deemed unsupported or not useful, the graph loops back to either regenerate or perform a web search to fill information gaps, ultimately concluding only when a high-quality, grounded response is produced.

        ## Tools
        - `vector_store_search`
- `document_grader`
- `perform_web_search`
- `generate_response`
- `validate_response`

        ## Usage
        ```bash
        cd output/rag_system
        export OPENAI_API_KEY=your_key_here
        python run.py "Your query here"
        ```

        ## Fingerprint
        `N/A`
