        # real_estate_assistant

        An AI agent for: This agent is designed as a real estate assistant that coordinates specialized agents to provide property insights and financial calculations. The system utilizes a supervisor agent to analyze user queries, extract property names, and determine the appropriate routing logic. The data flow begins at the supervisor_command_node, which uses structured output to either respond directly to general inquiries or route the conversation to the transaction_history_agent_node for market data and valuation or the property_profile_agent_node for detailed property features and lease information. Information is managed through a shared SupervisorState that tracks message history and the extracted property name, which acts as context for the specialist agents. Each specialist agent leverages domain-specific tools, such as mortgage affordability or price-per-square-foot calculators, before returning a Command to terminate the graph execution with a final response.

        ## Tools
        - `fetch_market_data`
- `calculate_property_valuation`
- `retrieve_property_features`
- `get_lease_information`

        ## Usage
        ```bash
        cd output/real_estate_assistant
        export OPENAI_API_KEY=your_key_here
        python run.py "Your query here"
        ```

        ## Fingerprint
        `N/A`
