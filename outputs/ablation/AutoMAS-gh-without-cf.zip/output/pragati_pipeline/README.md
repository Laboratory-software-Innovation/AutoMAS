        # pragati_pipeline

        An AI agent for: The PRAGATI pipeline is an agent designed to automate the evaluation of research papers by performing simultaneous qualitative analysis and factual verification. The workflow begins at the START node, where the PaperState is branched into two parallel nodes: qa_node, which executes a critic graph to assess the paper's publishability and suggestions, and fact_checker_node, which invokes a dedicated fact-checking graph to determine factual accuracy and calculate a credibility score. The results from these concurrent processes flow into the combine_results_node, where the individual assessments—including factual status, average scores, and reviewer suggestions—are aggregated into a final PaperState. The process concludes at the END node, yielding a comprehensive assessment that evaluates the document's scholarly quality and integrity.

        ## Tools
        - `qualitative_analysis_tool`
- `factual_verification_tool`
- `combine_results_tool`

        ## Usage
        ```bash
        cd output/pragati_pipeline
        export OPENAI_API_KEY=your_key_here
        python run.py "Your query here"
        ```

        ## Fingerprint
        `N/A`
