        # soc_workflow

        An AI agent for: This agent is designed as an automated Security Operations Center (SOC) workflow that performs end-to-end incident analysis and reporting. The data flow begins at the ioc_agent node, which extracts Indicators of Compromise from the input incident text, then moves to the mitre_agent to map those findings to specific TTPs. This context is passed to the cve_agent to identify relevant software vulnerabilities, which in turn feeds into the investigation_agent to generate a detailed DFIR investigation and containment plan. The process concludes at the report_agent node, which synthesizes all previous state data—including IOCs, MITRE tactics, CVEs, and the investigation plan—into a structured JSON and plain-text report for final delivery.

        ## Tools
        - `ioc_extraction_tool`
- `mitre_mapping_tool`
- `cve_identification_tool`
- `dfir_investigation_tool`
- `report_synthesis_tool`

        ## Usage
        ```bash
        cd output/soc_workflow
        export OPENAI_API_KEY=your_key_here
        python run.py "Your query here"
        ```

        ## Fingerprint
        `N/A`
