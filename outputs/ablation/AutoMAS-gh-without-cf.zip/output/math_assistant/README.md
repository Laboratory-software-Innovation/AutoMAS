        # math_assistant

        An AI agent for: This agent is designed as a specialized mathematical assistant that utilizes a stateful graph to process user queries through distinct expert nodes. Its primary purpose is to orchestrate a workflow for handling addition and multiplication tasks using the MessagesState to maintain a shared conversation history. The data flow is initiated at the START node, which directs the input state immediately to the additional_expert node for processing. Although a multiplication_expert node is defined within the graph structure, the current execution path explicitly connects the entry point to the addition-focused component, where it transforms the incoming message state before the graph is compiled into an executable application for visualization and interaction.

        ## Tools
        - `addition_tool`
- `multiplication_tool`
- `manage_messages_state`

        ## Usage
        ```bash
        cd output/math_assistant
        export OPENAI_API_KEY=your_key_here
        python run.py "Your query here"
        ```

        ## Fingerprint
        `N/A`
