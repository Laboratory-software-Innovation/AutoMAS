        # multi_persona_research_assistant

        An AI agent for: This agent is designed as an automated AI research assistant that generates comprehensive reports by simulating a multi-persona analyst interview process. The data flow begins at the create_analysts node, which generates three distinct AI personas tailored to a user-provided topic. The process then enters a conditional loop at the conduct_interview node, where each analyst persona iteratively generates insightful questions, performs external research using the Tavily and Wikipedia APIs, and synthesizes the findings into individual report sections. Once all personas have contributed, the graph transitions to the write_report node to aggregate the findings, followed by the write_intro_conclusion node to frame the content. The workflow culminates in the finalize_report node, which assembles the final document for display and download within a Streamlit interface, ensuring a structured and multi-perspective analysis of the research topic.

        ## Tools
        - `generate_insightful_questions`
- `perform_external_research`
- `synthesize_findings`
- `aggregate_report_sections`
- `write_intro_conclusion`

        ## Usage
        ```bash
        cd output/multi_persona_research_assistant
        export OPENAI_API_KEY=your_key_here
        python run.py "Your query here"
        ```

        ## Fingerprint
        `N/A`
