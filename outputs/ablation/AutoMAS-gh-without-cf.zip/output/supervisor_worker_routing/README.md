        # supervisor_worker_routing

        An AI agent for: This orchestration follows a supervisor-worker pattern designed to route user inquiries to specialized sub-agents for currency exchange and weather information. The architecture centers on a supervisor node that manages the workflow by analyzing the input message and delegating tasks to either the currency_agent—which utilizes a tool to fetch USD to JPY exchange rates—or the weather_agent, which uses a tool to provide current weather conditions for a specified location. The data flow begins with a HumanMessage being processed by the supervisor, which acts as a router to prevent parallel agent calls and ensure a single-agent-at-a-time execution. State and conversation history are preserved across the graph using a MemorySaver checkpointer, allowing for context-aware interactions. The process concludes once the designated agent fulfills the request and returns the specialized output through the compiled workflow, ensuring the supervisor does not perform the domain-specific tasks itself.

        ## Tools
        - `fetch_usd_to_jpy_exchange_rate`
- `fetch_current_weather`

        ## Usage
        ```bash
        cd output/supervisor_worker_routing
        export OPENAI_API_KEY=your_key_here
        python run.py "Your query here"
        ```

        ## Fingerprint
        `N/A`
