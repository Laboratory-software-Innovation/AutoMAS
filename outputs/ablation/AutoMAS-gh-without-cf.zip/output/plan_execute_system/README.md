# plan_execute_system

An AI agent for: This agent is designed as a multi-agent search and task execution system that follows a plan-and-execute workflow to solve complex user objectives. The data flow begins at the planner node, which decomposes the initial user input into a structured list of steps. This plan is passed to the executor node, which processes the first task in the plan and records the results into a state-managed history of past steps. The process then moves to the replanner node, which evaluates the progress based on the full state; if the task is complete, it generates a final response, but if further action is required, it updates the plan and loops back to the executor. This cycle of execution and adaptive replanning continues until the should_end condition is met, ensuring a systematic and iterative approach to fulfilling the user's request.

## Tools
- `execute_task`

## Usage
```bash
cd output/plan_execute_system
export OPENAI_API_KEY=your_key_here
python run.py "Your query here"
```

## Fingerprint
`N/A`
