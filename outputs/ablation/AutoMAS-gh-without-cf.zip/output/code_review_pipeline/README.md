        # code_review_pipeline

        An AI agent for: This agent is designed as an automated code generation and multi-expert review system that ensures production-ready Python code through a supervised workflow. The process begins at the coder node, where a Senior Software Engineer agent generates initial implementation based on user input. The data then flows to the supervisor node, which acts as a central orchestrator, managing the iterative review cycle by tracking completed tasks in the state. Using conditional edges, the supervisor routes the code first to the security_expert for vulnerability assessment and then to the quality_expert for maintainability and structure analysis. Each expert updates the shared state with their respective findings and returns control to the supervisor. Once both specialized reviews are finalized, the workflow transitions to the synthesis node, where a final report is compiled, integrating all recommendations before concluding the process at the end of the graph.

        ## Tools
        - `security_analysis_tool`
- `quality_analysis_tool`
- `compile_final_report`

        ## Usage
        ```bash
        cd output/code_review_pipeline
        export OPENAI_API_KEY=your_key_here
        python run.py "Your query here"
        ```

        ## Fingerprint
        `N/A`
