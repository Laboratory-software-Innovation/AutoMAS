        # llm_evaluation_framework

        An AI agent for: The provided code implements an evaluation framework designed to benchmark Large Language Model (LLM) agents within the ScienceWorld environment. Its primary purpose is to facilitate agent-environment interactions through a ReAct-style loop, where a meta-agent generates descriptions to refine and guide sub-agent actions. The data flow begins with task initialization and moves through a collaboration mechanism that manages conversation history, token limits, and performance logging across various models. This structured approach ensures that information is iteratively processed to refine agent decisions, ultimately documenting their problem-solving capabilities in scientific and household scenarios for comparative analysis.

        ## Tools
        - `environment_interaction_tool`
- `conversation_history_manager`
- `performance_logging_tool`
- `task_initialization_tool`

        ## Usage
        ```bash
        cd output/llm_evaluation_framework
        export OPENAI_API_KEY=your_key_here
        python run.py "Your query here"
        ```

        ## Fingerprint
        `N/A`
