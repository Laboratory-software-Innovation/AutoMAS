# scientific_proposal_pipeline

An AI agent for: The code establishes a multi-agent collaborative framework using AutoGen to automate scientific discovery and research proposal development. Its core intent is to transform raw knowledge graph data into a structured, peer-reviewed scientific proposal through a specialized pipeline: a planner orchestrates the workflow, an ontologist defines concepts, a scientist synthesizes a seven-part proposal, and individual domain agents expand each section with quantitative detail. The data flow is managed by a GroupChatManager that facilitates information transfer from knowledge extraction to expansion, concluding with a critic agent for evaluation and a novelty assistant that validates the hypothesis against external literature via the Semantic Scholar API.

## Tools
- `semantic_scholar_api`

## Usage
```bash
cd output/scientific_proposal_pipeline
export OPENAI_API_KEY=your_key_here
python run.py "Your query here"
```

## Fingerprint
`N/A`
