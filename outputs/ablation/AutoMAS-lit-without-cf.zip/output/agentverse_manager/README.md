        # agentverse_manager

        An AI agent for: The AgentVerse class provides a framework for managing multi-agent environments by orchestrating the lifecycle and interactions of various agents based on predefined task configurations. Its primary intent is to automate the initialization of agents and environments from YAML-based task directories, facilitating a structured data flow where the environment processes steps, updates agent states, and handles input/output paths. Information moves through the system via a centralized execution loop that resets the environment and agents, then iteratively triggers asynchronous steps until a task is completed, returning messages from the environment to manage the conversation or task progression.

        ## Tools
        - `initialize_agents_and_environments`
- `process_environment_steps`
- `update_agent_states`
- `manage_io_paths`

        ## Usage
        ```bash
        cd output/agentverse_manager
        export OPENAI_API_KEY=your_key_here
        python run.py "Your query here"
        ```

        ## Fingerprint
        `N/A`
