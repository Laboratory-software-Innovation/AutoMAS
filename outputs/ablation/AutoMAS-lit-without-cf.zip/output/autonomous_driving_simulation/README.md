        # autonomous_driving_simulation

        An AI agent for: The code implements an autonomous driving simulation framework that utilizes Large Language Model (LLM) agents to control multiple vehicles within a Gymnasium-based highway environment. The primary intent is to evaluate agent decision-making, memory retrieval, and self-reflection capabilities in complex merging scenarios. Data flows from the environment as scenario descriptions and available actions into the Driver Agents, which can optionally retrieve past experiences from a vector-based memory module and apply few-shot reasoning to generate driving plans. Post-simulation, a reflection mechanism analyzes performance scores and collision data to identify mistakes, generating corrected responses that are then stored back into the memory module to improve future performance.

        ## Tools
        - `retrieve_memory`
- `generate_driving_plan`
- `analyze_performance_scores`
- `generate_corrected_responses`
- `store_corrected_responses`

        ## Usage
        ```bash
        cd output/autonomous_driving_simulation
        export OPENAI_API_KEY=your_key_here
        python run.py "Your query here"
        ```

        ## Fingerprint
        `N/A`
