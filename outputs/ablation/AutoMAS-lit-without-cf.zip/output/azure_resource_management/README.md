        # azure_resource_management

        An AI agent for: The Azure Resource Management Assistant (ARMA) agent is designed to automate and manage Azure infrastructure deployments through a structured LangChain-based factory pattern. Its primary intent is to provide a secure, human-in-the-loop interface for resource management, utilizing a suite of tools for planning, executing, and deleting resources while ensuring RBAC compliance and policy alignment. The data flow follows a middleware-heavy pipeline where user requests are enriched with dynamic system prompts and context, validated for permissions via preflight checks, and processed through a task-tracking middleware that breaks complex deployments into manageable steps. Information moves from the initial request through a sequence of state-preserving layers—including conversation summarization, resource tagging, and usage tracking—eventually reaching a decision point where critical operations like deployment execution or resource deletion trigger an interrupt for manual human approval before the final state is committed.

        ## Tools
        - `validate_permissions`
- `plan_resource_deployment`
- `execute_deployment`
- `tag_resources`
- `track_usage`

        ## Usage
        ```bash
        cd output/azure_resource_management
        export OPENAI_API_KEY=your_key_here
        python run.py "Your query here"
        ```

        ## Fingerprint
        `N/A`
