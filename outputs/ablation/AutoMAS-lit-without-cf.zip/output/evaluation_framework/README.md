        # evaluation_framework

        An AI agent for: The code implements an evaluation framework for testing Large Language Model agents within the ScienceWorld environment. Its core intent is to facilitate agent-environment interaction through a ReAct-style loop, utilizing a collaboration mechanism where a meta-agent generates descriptions to refine sub-agent actions. The system manages task initialization, conversation history, token limits, and performance logging across various models to benchmark their problem-solving capabilities in scientific and household scenarios.

        ## Tools
        - `initialize_scienceworld_environment`
- `facilitate_agent_interaction`
- `generate_action_descriptions`
- `log_performance_metrics`

        ## Usage
        ```bash
        cd output/evaluation_framework
        export OPENAI_API_KEY=your_key_here
        python run.py "Your query here"
        ```

        ## Fingerprint
        `N/A`
