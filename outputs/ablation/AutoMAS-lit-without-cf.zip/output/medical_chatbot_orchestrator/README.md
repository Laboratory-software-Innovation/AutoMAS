        # medical_chatbot_orchestrator

        An AI agent for: This code implements an orchestration layer for a multi-agent medical chatbot to manage complex diagnostic and informational workflows. Its core intent is to act as a central decision system that dynamically routes user queries to specialized agents, such as a RAG-based retrieval unit, based on the semantic content and conversational context. The data flow follows a state-based architecture where user inputs are processed through a StateGraph, transitioning between message states and utility functions to ensure pertinent medical information is retrieved and synthesized before returning a structured response to the user.

        ## Tools
        - `semantic_content_analysis`
- `contextual_query_routing`
- `diagnostic_data_retrieval`
- `information_retrieval`
- `response_synthesis`

        ## Usage
        ```bash
        cd output/medical_chatbot_orchestrator
        export OPENAI_API_KEY=your_key_here
        python run.py "Your query here"
        ```

        ## Fingerprint
        `N/A`
