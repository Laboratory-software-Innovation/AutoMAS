        # dual_agent_system

        An AI agent for: The code implements a dual-agent software engineering system comprising an architect and a developer, designed to autonomously research, plan, and implement code changes. The architect agent initiates the workflow by iteratively proposing and validating research steps to build a comprehensive implementation plan, using tools to explore the codebase and external data. Once the plan is extracted, it flows to the developer agent, which executes tasks by reading file contents and conducting specific implementation research for each atomic sub-task. The system utilizes conditional edges to manage tool-calling loops and task completion, ultimately applying code modifications via a diffing mechanism that updates files based on the synthesized research and instructions.

        ## Tools
        - `explore_codebase`
- `fetch_external_data`
- `read_file_contents`
- `conduct_implementation_research`
- `apply_code_diff`

        ## Usage
        ```bash
        cd output/dual_agent_system
        export OPENAI_API_KEY=your_key_here
        python run.py "Your query here"
        ```

        ## Fingerprint
        `N/A`
