        # pso_travel_planner

        An AI agent for: This code implements a Particle Swarm Optimization (PSO) framework to refine a team of agents for the TravelPlanner task. Its primary intent is to iteratively improve agent configurations (positions) and their underlying workflows (velocity) by simulating a swarm of particles that evaluate performance against a dataset. Data flows from the initialization of particles with specific LLM settings into an evaluation phase where agent teams execute tasks, receive multi-faceted feedback, and calculate fitness scores based on constraint pass rates. This feedback is then used to update particle velocities by reflecting on both personal and global best positions, ultimately driving the agents to evolve more effective strategies and code for complex travel planning queries.

        ## Tools
        - `evaluate_particle_performance`
- `process_feedback`
- `update_particle_velocity`
- `check_termination_criteria`

        ## Usage
        ```bash
        cd output/pso_travel_planner
        export OPENAI_API_KEY=your_key_here
        python run.py "Your query here"
        ```

        ## Fingerprint
        `N/A`
