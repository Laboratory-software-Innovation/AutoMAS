        # poster_generation_pipeline

        An AI agent for: The code implements the Poster Generation pipeline, a multi-agent system designed to automate the transformation of scientific PDF papers into aesthetic conference posters. The workflow orchestrates a sequential data flow where a shared state is progressively enriched by specialized agents responsible for parsing text, curating content, selecting color schemes, designing titles, optimizing layouts, and choosing fonts. The process culminates in a rendering node that generates a final .pptx file, while a timing wrapper and logging utility track performance metrics, API usage, and token costs across the entire graph execution.

        ## Tools
        - `pdf_extractor`
- `content_selector`
- `color_scheme_generator`
- `title_generator`
- `layout_optimizer`
- `font_selector`
- `pptx_renderer`
- `performance_logger`

        ## Usage
        ```bash
        cd output/poster_generation_pipeline
        export OPENAI_API_KEY=your_key_here
        python run.py "Your query here"
        ```

        ## Fingerprint
        `N/A`
