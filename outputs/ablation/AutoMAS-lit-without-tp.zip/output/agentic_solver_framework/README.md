# agentic_solver_framework

An AI agent for: The code implements an agentic solver framework designed to resolve complex user queries by orchestrating a structured interaction between specialized modules: a planner, an executor, a verifier, and a memory system. Its primary purpose is to decompose problems into iterative, tool-assisted steps, allowing for multi-step reasoning and external information retrieval. The data flow begins with the planner analyzing the input query to establish an initial strategy, followed by a main execution loop where the planner predicts sub-goals and specific tools, the executor generates and runs commands to produce results, and the memory module stores each action for context. Each iteration is processed by a verifier to check for task completion, and once solved or the limit is reached, the accumulated reasoning and tool data are synthesized into final responses.

## Tools
- No external tools

## Usage
```bash
cd output/agentic_solver_framework
export OPENAI_API_KEY=your_key_here
python run.py "Your query here"
```

## Fingerprint
`N/A`
