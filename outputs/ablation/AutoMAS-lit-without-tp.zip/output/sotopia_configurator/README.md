# sotopia_configurator

An AI agent for: The provided code serves as a configuration and execution wrapper for the Sotopia evaluation framework, designed to automate the setup of agent-based social simulations. Its primary purpose is to dynamically modify a template bash script by overwriting specific parameters—such as unique experiment tags, environment identifiers, batch sizes, and model versions for two distinct agents—using regular expressions. The data flow begins with the ingestion of command-line arguments and a JSON file containing environment IDs; these inputs are processed to update the evaluation script on disk, which is then executed via a subprocess call to trigger the simulation. This system ensures consistent and reproducible benchmarking of Large Language Model agents by managing the transition from static configuration files to live execution environments.

## Tools
- No external tools

## Usage
```bash
cd output/sotopia_configurator
export OPENAI_API_KEY=your_key_here
python run.py "Your query here"
```

## Fingerprint
`N/A`
