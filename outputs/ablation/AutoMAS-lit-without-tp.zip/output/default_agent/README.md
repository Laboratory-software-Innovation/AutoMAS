# default_agent

An AI agent for: 

## Tools
- No external tools

## Usage
```bash
cd output/default_agent
export OPENAI_API_KEY=your_key_here
python run.py "Your query here"
```

## Fingerprint
`N/A`
