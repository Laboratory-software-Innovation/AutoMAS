# mine_dojo_pipeline

An AI agent for: The code implements an autonomous agent framework within the MineDojo environment designed to execute complex, multi-stage tasks like harvesting resources. Its core intent is to orchestrate a modular pipeline consisting of a Planner for high-level workflow decision-making, a Percipient for multimodal environment perception (supporting both active and caption-based models), and a Performer for action execution. Data flows from the environment into a centralized Memory module, which synchronizes observations and successful workflows to inform the Planner's logic. The system operates in an iterative loop, where the Patroller validates task success or provides feedback for retries, ensuring that information regarding inventory, spatial state via LiDAR and voxels, and historical actions continuously updates the agent's strategy until the objective is achieved or maximum retries are reached.

## Tools
- No external tools

## Usage
```bash
cd output/mine_dojo_pipeline
export OPENAI_API_KEY=your_key_here
python run.py "Your query here"
```

## Fingerprint
`N/A`
