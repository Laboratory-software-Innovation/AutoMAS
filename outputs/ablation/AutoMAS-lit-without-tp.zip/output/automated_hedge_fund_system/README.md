# automated_hedge_fund_system

An AI agent for: The code implements an automated hedge fund trading system using a StateGraph workflow to orchestrate multi-agent financial analysis. Its core intent is to generate trading decisions by routing stock tickers and portfolio data through a sequence of specialized analyst nodes, a risk management agent, and a final portfolio manager. Data flows from an initial start node to a user-defined set of analysts who generate market signals; these signals are then aggregated and vetted by the risk management agent before the portfolio manager produces the final JSON-formatted trading instructions. The system maintains a global AgentState that tracks message history, ticker data, and analyst signals, ensuring a structured progression from raw input to validated financial execution.

## Tools
- No external tools

## Usage
```bash
cd output/automated_hedge_fund_system
export OPENAI_API_KEY=your_key_here
python run.py "Your query here"
```

## Fingerprint
`N/A`
