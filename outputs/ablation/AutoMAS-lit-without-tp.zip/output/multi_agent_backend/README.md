# multi_agent_backend

An AI agent for: The code implements a backend infrastructure for a multi-agent system using FastAPI and LangGraph, designed to manage the lifecycle and state of specialized agents like llamabot and llamapress. Its core intent is to provide a scalable communication layer that routes user requests from a WebSocket interface to specific pre-compiled stategraphs, ensuring that agent memory is preserved either in volatile RAM or a persistent PostgreSQL database via a checkpointer. Data flow begins with the identification of the target agent from an incoming message payload, followed by the execution of the corresponding graph where information processes through defined nodes, with the resulting state automatically saved before the final response is returned to the client.

## Tools
- No external tools

## Usage
```bash
cd output/multi_agent_backend
export OPENAI_API_KEY=your_key_here
python run.py "Your query here"
```

## Fingerprint
`N/A`
