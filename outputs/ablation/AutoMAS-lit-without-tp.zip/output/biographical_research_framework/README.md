# biographical_research_framework

An AI agent for: The code implements a research agent framework designed to conduct deep biographical investigations by orchestrating automated web searches, content crawling, and data synthesis. Its core intent is to automate the discovery and structuring of key life events through a multi-stage StateGraph architecture where a supervisor node decides between conducting further research using a ResearchEventsTool, reflecting on progress with a think_tool, or finalizing the task. The data flow begins with a url_finder that identifies high-value sources, followed by a looping router that manages recursive crawling and event extraction via specialized subgraphs, eventually merging all findings into a categorized state. Finally, the gathered unstructured information is passed through a structuring node that uses a language model to transform raw biographical data into a standardized JSON chronology, ensuring a comprehensive and organized historical record of the subject.

## Tools
- No external tools

## Usage
```bash
cd output/biographical_research_framework
export OPENAI_API_KEY=your_key_here
python run.py "Your query here"
```

## Fingerprint
`N/A`
