# multi_agent_orchestration

An AI agent for: The code implements a multi-agent orchestration framework designed to automate data science and machine learning workflows. Its core intent is to act as a high-level manager that receives complex user requirements via structured JSON and decomposes them into actionable plans for specialized sub-agents, including Prompt, Data, Model, and Operation agents. The data flow begins with the manager retrieving relevant knowledge to inform plan generation, then distributing tasks across these specialized agents through a coordinated pipeline. This system leverages parallel processing and integrated retrievers to ensure that information moves from initial inquiry through specialized execution states, ultimately delivering high-quality, research-driven outcomes for MLOps and data engineering tasks.

## Tools
- No external tools

## Usage
```bash
cd output/multi_agent_orchestration
export OPENAI_API_KEY=your_key_here
python run.py "Your query here"
```

## Fingerprint
`N/A`
