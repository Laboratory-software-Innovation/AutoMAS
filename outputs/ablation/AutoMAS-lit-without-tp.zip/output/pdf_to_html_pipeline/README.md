# pdf_to_html_pipeline

An AI agent for: The code implements an automated pipeline for generating research project pages from PDF documents by managing state transitions through a centralized GenerationState object. Its core intent is to transform raw academic papers into structured HTML content through a multi-step process involving PDF parsing, content filtering via a specialized planner agent, and iterative section generation. The data flow begins with capturing user input into a global state, followed by external parsing into markdown and metadata, which is then filtered and refined through a human-in-the-loop feedback mechanism to ensure the structural design meets user expectations. Finally, the system synthesizes the filtered content and approved sections into detailed text and a final HTML representation, maintaining data consistency across the state object throughout the lifecycle.

## Tools
- No external tools

## Usage
```bash
cd output/pdf_to_html_pipeline
export OPENAI_API_KEY=your_key_here
python run.py "Your query here"
```

## Fingerprint
`N/A`
