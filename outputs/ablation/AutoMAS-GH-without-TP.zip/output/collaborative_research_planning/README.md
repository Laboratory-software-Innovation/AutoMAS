        # collaborative_research_planning

        An AI agent for: This swarm agent is designed as a collaborative research and planning system that utilizes a handoff mechanism between two specialized agents, the planner_agent and the researcher_agent, to address user requests. The system's purpose is to provide a structured approach to problem-solving where the planner_agent serves as the initial entry point, focusing on clarifying the user's request and fetching relevant documentation through a specified LLMS.txt source. The data flow is governed by a swarm architecture where the planner_agent can transfer control to the researcher_agent to perform deep-dive research and implement solutions, while the researcher_agent can conversely hand back control if further clarification is needed. Both agents have access to a fetch_doc tool to ingest external information, and the entire process is compiled into a stateful application that defaults to the planner_agent to ensure a guided and iterative user experience.

        ## Tools
        - `fetch_doc`
- `search_external_information`
- `clarify_user_request`

        ## Usage
        ```bash
        cd output/collaborative_research_planning
        export OPENAI_API_KEY=your_key_here
        python run.py "Your query here"
        ```

        ## Fingerprint
        `N/A`
