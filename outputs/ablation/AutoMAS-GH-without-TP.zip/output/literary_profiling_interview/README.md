        # literary_profiling_interview

        An AI agent for: This Python-based CLI agent is designed to facilitate an interactive literary profiling interview by leveraging the Kimi K2 thinking model to gather user insights and generate a comprehensive persona. The data flow begins with the initialization of specialized agents—InterviewAgent, ReasoningExtractor, and ProfileGeneratorAgent—and manages a multi-turn conversation loop that tracks user responses and assistant messages within a session-specific history. Information is passed to the InterviewAgent to drive the dialogue, while the ReasoningExtractor optionally surfaces the model's underlying thought process to the user. Upon reaching a 12-turn limit, receiving a completion signal from the agent, or an early exit command, the accumulated conversation history is processed by the ProfileGeneratorAgent to synthesize a detailed literary profile. The final output is then structured and persisted to the local file system in both JSON and Markdown formats via the ProfileSaver tool, ensuring a seamless transition from raw interactive data to a structured analytical summary.

        ## Tools
        - `track_conversation_history`
- `process_conversation_history`
- `save_profile_to_json`
- `save_profile_to_markdown`

        ## Usage
        ```bash
        cd output/literary_profiling_interview
        export OPENAI_API_KEY=your_key_here
        python run.py "Your query here"
        ```

        ## Fingerprint
        `N/A`
