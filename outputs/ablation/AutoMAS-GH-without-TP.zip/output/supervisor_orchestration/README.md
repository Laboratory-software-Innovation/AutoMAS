        # supervisor_orchestration

        An AI agent for: This agent is designed as a multi-agent orchestration system that utilizes a supervisor-led architecture to coordinate specialized tasks between a Researcher and a Coder. The intent is to delegate complex user queries to specific sub-agents: the "Researcher," which uses the Tavily search tool for information retrieval, and the "Coder," which utilizes a Python REPL tool for technical execution and computation. The data flow is governed by a central supervisor node that serves as the entry point and decision-maker; it routes work to the appropriate agent node, which then returns its results to the supervisor. This cycle continues through conditional edges that map agent outputs back to the supervisor until a "FINISH" signal is reached, at which point the graph transitions to the final end state, ensuring a collaborative and iterative workflow for multifaceted problem-solving.

        ## Tools
        - `tavily_search_tool`
- `python_repl_tool`
- `supervisor_decision_maker`
- `result_aggregator`

        ## Usage
        ```bash
        cd output/supervisor_orchestration
        export OPENAI_API_KEY=your_key_here
        python run.py "Your query here"
        ```

        ## Fingerprint
        `N/A`
