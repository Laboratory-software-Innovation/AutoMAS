        # enhanced_rag_chatbot

        An AI agent for: This agent is designed as an enhanced RAG-based chatbot that provides accurate, context-aware answers by processing user queries and performing hybrid document retrieval. The data flow begins at the process_query node, where it cleans the input and generates search vectors, before moving to the chunk_and_embed node to break documents into segments using a RecursiveCharacterSplitter. Information then flows to the retrieve_chunks node, which executes a hybrid search combining 70% semantic similarity and 30% BM25 keyword matching to identify the most relevant context. Finally, the generate_response node utilizes the Gemma-3 LLM to synthesize these findings into a coherent answer, completing a linear path from ingestion to reasoning that ensures high-fidelity information retrieval.

        ## Tools
        - `clean_and_vectorize_query`
- `chunk_documents`
- `hybrid_search_retrieve`
- `synthesize_response`

        ## Usage
        ```bash
        cd output/enhanced_rag_chatbot
        export OPENAI_API_KEY=your_key_here
        python run.py "Your query here"
        ```

        ## Fingerprint
        `N/A`
