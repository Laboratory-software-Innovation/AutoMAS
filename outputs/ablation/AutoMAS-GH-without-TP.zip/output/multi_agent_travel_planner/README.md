        # multi_agent_travel_planner

        An AI agent for: This Python-based Multi-Agent AI Travel Planning System is designed to provide collaborative and optimized trip planning by orchestrating six specialized agents: a Coordinator, Travel Advisor, Budget Optimizer, Weather Analyst, Local Expert, and Itinerary Planner. The system's data flow begins with the UserInputHandler, which captures comprehensive trip details and passes them to the MultiAgentTravelOrchestrator. This orchestrator manages the collaboration between specialized agents to synthesize a multidimensional plan that balances cost, weather, and logistics through consensus-based decision-making. The resulting comprehensive_plan is then processed to display detailed insights—including destination highlights, budget breakdowns, and contingency plans—and can be exported as a structured report. The system maintains high transparency by tracking and displaying performance metrics such as agent consensus levels, confidence scores, and communication hub health, ensuring a validated and user-centric travel itinerary.

        ## Tools
        - `fetch_destination_information`
- `search_travel_reviews`
- `compare_travel_options`

        ## Usage
        ```bash
        cd output/multi_agent_travel_planner
        export OPENAI_API_KEY=your_key_here
        python run.py "Your query here"
        ```

        ## Fingerprint
        `N/A`
