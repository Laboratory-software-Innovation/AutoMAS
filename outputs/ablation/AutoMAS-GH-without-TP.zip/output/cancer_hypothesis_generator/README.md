        # cancer_hypothesis_generator

        An AI agent for: This hypothesis generator is designed to assist cancer researchers by proposing novel biological hypotheses based on statistical model outputs, such as gene importance and disease variables. The agent functions as an iterative research loop that begins with a draft node, where an initial responder generates a hypothesis using Pydantic-validated structures. The data then flows into an execute_tools node that uses a retrieval chain and Chroma vector database to search PubMed literature for relevant publications. This information is passed to a revise node, where the agent critiques its own work for novelty, complexity, and validity, incorporating citations and addressing superfluous or missing information. The graph employs a conditional event loop that continues this refinement process for a user-defined number of iterations, ultimately outputting a detailed dataframe containing the hypothesis, novelty scores, and literature relations while utilizing NeMo Guardrails to flag potential biohazards or restricted topics.

        ## Tools
        - `pubmed_search_tool`
- `nemo_guardrails`

        ## Usage
        ```bash
        cd output/cancer_hypothesis_generator
        export OPENAI_API_KEY=your_key_here
        python run.py "Your query here"
        ```

        ## Fingerprint
        `N/A`
