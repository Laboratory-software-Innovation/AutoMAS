        # iterative_report_writer

        An AI agent for: This agent is designed as an iterative report-writing assistant that automates the process of planning, researching, drafting, and refining professional reports. The workflow begins at the planner node, which generates an initial outline based on a user-provided task, followed by the research_plan node, which uses the Tavily API to gather relevant information. The data then flows to the generate node to produce a first draft, which is subsequently evaluated by the reflect node to provide constructive critique. If further improvements are needed, the research_critique node identifies additional search queries to address the feedback, looping back into the generation phase. This cycle repeats until the specified maximum number of revisions is reached, at which point the final report is produced, ensuring a high-quality, research-backed document through structured self-correction.

        ## Tools
        - `evaluate_draft_quality`
- `identify_additional_research_queries`
- `search_additional_information`

        ## Usage
        ```bash
        cd output/iterative_report_writer
        export OPENAI_API_KEY=your_key_here
        python run.py "Your query here"
        ```

        ## Fingerprint
        `N/A`
