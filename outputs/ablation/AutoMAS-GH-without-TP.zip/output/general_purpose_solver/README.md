        # general_purpose_solver

        An AI agent for: This LangChain-based ReAct agent is designed as a general-purpose problem solver that combines reasoning with external tool execution to answer complex queries, such as mathematical calculations and real-time information retrieval. The agent’s purpose is to leverage a GPT-3.5 Turbo model to coordinate between a Python AST REPL for executing code and a DuckDuckGo Search tool for accessing current events. The data flow follows the ReAct framework: the agent receives a user prompt, pulls a reasoning template from LangChain Hub, and enters a thought-action-observation loop where it iteratively determines the necessary tool, executes the action, and evaluates the output. This process continues for up to 10 iterations or until a final answer is synthesized, ensuring that complex tasks like multi-step math or web-based research are handled through structured, observable reasoning steps.

        ## Tools
        - `python_ast_repl`
- `web_search`

        ## Usage
        ```bash
        cd output/general_purpose_solver
        export OPENAI_API_KEY=your_key_here
        python run.py "Your query here"
        ```

        ## Fingerprint
        `N/A`
