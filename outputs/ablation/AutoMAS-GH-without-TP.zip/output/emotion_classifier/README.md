        # emotion_classifier

        An AI agent for: This agent is designed as a self-healing emotion classifier that uses a fine-tuned transformer model to categorize text into specific emotional states while implementing a human-in-the-loop fallback mechanism for low-confidence predictions. The data flow begins at the inference node, where the user's input is processed by the model to generate a prediction and a confidence score. The graph then transitions to a conditionalnode that performs a confidence check; if the confidence is 0.65 or higher, the process concludes at the END state. However, if the confidence falls below this threshold, the flow is routed to a fallback node where a user is prompted to manually clarify the correct emotion, ensuring accuracy through human intervention and logging the correction for future refinement.

        ## Tools
        - `emotion_model_inference`
- `log_correction`
- `prompt_human_feedback`

        ## Usage
        ```bash
        cd output/emotion_classifier
        export OPENAI_API_KEY=your_key_here
        python run.py "Your query here"
        ```

        ## Fingerprint
        `N/A`
