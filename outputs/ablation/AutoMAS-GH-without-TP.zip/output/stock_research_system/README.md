        # stock_research_system

        An AI agent for: This StockResearchSystem is a multi-agent orchestration framework designed to provide automated, high-fidelity financial analysis and trading recommendations for stocks, particularly those listed on the NSE. The system utilizes a supervisor-managed architecture where a central supervisor agent directs tasks to four specialized sub-agents: a stock_finder_agent for identifying promising tickers, a market_data_agent for technical indicator analysis, a news_analyst_agent for sentiment evaluation, and a recommendation_agent for synthesizing findings into actionable trade signals. The data flow begins with a user query processed by the supervisor, which initializes a MultiServerMCPClient to fetch real-time web data via Bright Data; the supervisor then streams the objective through the specialized agents, capturing their iterative outputs into a unified message history. The process concludes by extracting structured data—including target prices, technical indicators, and sentiment scores—to generate a comprehensive final report for short-term trading decisions.

        ## Tools
        - `stock_ticker_finder_tool`
- `technical_indicator_analysis_tool`
- `sentiment_analysis_tool`
- `trade_signal_generator_tool`

        ## Usage
        ```bash
        cd output/stock_research_system
        export OPENAI_API_KEY=your_key_here
        python run.py "Your query here"
        ```

        ## Fingerprint
        `N/A`
