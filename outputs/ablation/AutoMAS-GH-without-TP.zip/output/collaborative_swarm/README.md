        # collaborative_swarm

        An AI agent for: This implementation establishes a collaborative swarm of specialized agents—internet_assistance, temperature_assistant, and Wikipedia_assistance—designed to resolve complex queries through autonomous handoffs. The data flow initiates at the internet_assistance agent, which serves as the default entry point for real-time web research and determines if the request requires routing to a specialist via dedicated handoff tools. If the query pertains to climate or weather, control is transferred to the temperature_assistant to utilize its specific measurement tools, while requests for deep background or biographical data are routed to the Wikipedia_assistance agent. This modular architecture allows for seamless state transitions between agents, where each participant can delegate tasks back to the internet expert or to another peer, all while maintaining conversation persistence through an InMemorySaver checkpointer to deliver a unified and accurate final response.

        ## Tools
        - `perform_web_search`
- `retrieve_weather_data`
- `fetch_wikipedia_data`

        ## Usage
        ```bash
        cd output/collaborative_swarm
        export OPENAI_API_KEY=your_key_here
        python run.py "Your query here"
        ```

        ## Fingerprint
        `N/A`
