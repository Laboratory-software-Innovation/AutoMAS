        # arxiv_web_search_assistant

        An AI agent for: This agent is designed as an Arxiv retriever and Web search assistant that facilitates research by dynamically accessing academic papers and real-time information. The workflow is structured as a state graph beginning at the assistant node, where a Llama 3.1 model processes user queries and determines if external information is required. If the assistant generates a tool call, the data flow routes through a conditional edge to the tools node, which executes either a document retrieval or a web search. The results are then cycled back to the assistant for synthesis. Once the assistant provides a final answer without further tool calls, the workflow reaches its end state, with the entire process managed asynchronously and rendered through a Streamlit interface.

        ## Tools
        - `fetch_arxiv_papers`
- `perform_web_search`

        ## Usage
        ```bash
        cd output/arxiv_web_search_assistant
        export OPENAI_API_KEY=your_key_here
        python run.py "Your query here"
        ```

        ## Fingerprint
        `N/A`
