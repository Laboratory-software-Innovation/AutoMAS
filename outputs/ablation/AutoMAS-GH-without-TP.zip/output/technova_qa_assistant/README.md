        # technova_qa_assistant

        An AI agent for: This agent is designed as a specialized Q&A assistant for TechNova Solutions Inc., utilizing a Retrieval-Augmented Generation (RAG) architecture to provide accurate information from internal documents. The data flow begins at the retrieve node, where the user's question is processed to fetch relevant context from a FAISS vector store containing split and embedded data from text and JSON sources. Once the documents are retrieved, the graph transitions to the generate node, which uses a ChatGoogleGenerativeAI model (gemini-2.5-pro) to synthesize a final answer based on the provided context and the original question. The process is orchestrated through a StateGraph that manages the GraphState—consisting of the question, retrieved documents, and generated response—ensuring a linear and efficient movement from data retrieval to final output generation.

        ## Tools
        - `retrieve_documents`
- `generate_response`

        ## Usage
        ```bash
        cd output/technova_qa_assistant
        export OPENAI_API_KEY=your_key_here
        python run.py "Your query here"
        ```

        ## Fingerprint
        `N/A`
