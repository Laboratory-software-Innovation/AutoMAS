        # medical_diagnostic_assistant

        An AI agent for: This agent is designed as an advanced AI medical assistant that performs structured diagnostic evaluations by gathering symptom data through a multi-turn interactive conversation and conducting deep research via the Perplexity API. The data flow begins at the interactive_conversation node, where it iteratively collects and extracts symptom details—tracking duration, severity, and triggers—until a threshold of information or question count is met. Once sufficient data is gathered, the graph transitions to the determine_research_needs node to query medical literature for probable conditions and diagnostic steps, followed by the generate_analysis node to produce a comprehensive report featuring a differential diagnosis with confidence scores and risk assessments. The process culminates in the final_response node, which delivers the structured medical report while maintaining a state-aware loop that allows users to reset the graph for new symptoms or continue the existing consultation.

        ## Tools
        - `query_medical_literature`
- `generate_differential_diagnosis`
- `state_management`

        ## Usage
        ```bash
        cd output/medical_diagnostic_assistant
        export OPENAI_API_KEY=your_key_here
        python run.py "Your query here"
        ```

        ## Fingerprint
        `N/A`
