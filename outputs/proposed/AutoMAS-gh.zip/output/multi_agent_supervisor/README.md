        # multi_agent_supervisor

        An AI agent for: This workflow is designed as a multi-agent supervisor system that orchestrates three specialized agents—Wikipedia_Expert, Internet_Expert, and Weather_Expert—to fulfill complex information requests. The core intent is to act as a central hub that intelligently delegates tasks based on the nature of the query: historical or general knowledge is routed to the Wikipedia agent, real-time search queries to the Internet agent, and climate data to the Weather agent. The data flow begins with a user message being processed by the supervisor node, which identifies the required expertise and routes the message to the appropriate worker agent. Each worker agent uses specific tools to retrieve information and returns its response to the supervisor, which then aggregates the findings into a final, unified output for the user, ensuring a comprehensive and context-aware interaction.

        ## Tools
        - `wikipedia_search_tool`
- `real_time_search_tool`
- `weather_data_fetch_tool`

        ## Usage
        ```bash
        cd output/multi_agent_supervisor
        export OPENAI_API_KEY=your_key_here
        python run.py "Your query here"
        ```

        ## Fingerprint
        `N/A`
