        # sql_documentation_assistant

        An AI agent for: This agent, implemented via the SQLAgent class, is designed as a specialized SQL and data analysis assistant that generates detailed documentation for database tables. The agent's data flow is structured around a StateGraph that maintains an AgentState consisting of a message history. The process begins at the llm node, where the model invokes a system prompt to act as a senior expert and processes the current message state. A conditional edge then evaluates the model's output; if the LLM initiates a function call (such as executing SQL), the graph transitions to the function node to invoke the necessary tools and append the results back to the state. This creates a loop between the tool execution and the LLM until no further function calls are required, at which point the graph reaches the END state, ensuring the final output is a concise and accurate response based on real-time data retrieval.

        ## Tools
        - `execute_sql_query`
- `parse_sql_results`
- `generate_table_documentation`

        ## Usage
        ```bash
        cd output/sql_documentation_assistant
        export OPENAI_API_KEY=your_key_here
        python run.py "Your query here"
        ```

        ## Fingerprint
        `N/A`
