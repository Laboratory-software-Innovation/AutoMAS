        # blog_to_linkedin_post

        An AI agent for: This multi-agent system is designed to automate the transformation of blog content into LinkedIn-ready posts by orchestrating specialized roles for web scraping and content generation. The workflow begins with the BlogScraper component, which extracts raw data from a specified blog source. This data is then passed into a collaborative multi-agent environment where a UserProxyAgent coordinates with an AssistantAgent powered by Google Gemini. The data flow centers on the initiate_postmaking_process, which ingests the scraped "blog_1" content and moves it through an iterative exchange between the agents to summarize and format the information for social media. By leveraging this structured interaction, the system ensures that long-form blog text is refined into a concise, professional LinkedIn summary through automated prompting and response handling.

        ## Tools
        - `web_scraping_tool`
- `content_summarization_tool`
- `linkedin_post_formatter`

        ## Usage
        ```bash
        cd output/blog_to_linkedin_post
        export OPENAI_API_KEY=your_key_here
        python run.py "Your query here"
        ```

        ## Fingerprint
        `N/A`
