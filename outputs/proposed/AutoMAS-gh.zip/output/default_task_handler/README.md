        # default_task_handler

        An AI agent for: 

        ## Tools
        - `fetch_web_data`
- `parse_html_content`
- `search_information_online`
- `process_text_data`

        ## Usage
        ```bash
        cd output/default_task_handler
        export OPENAI_API_KEY=your_key_here
        python run.py "Your query here"
        ```

        ## Fingerprint
        `N/A`
