        # stock_market_rag_assistant

        An AI agent for: This agent is designed as an intelligent RAG (Retrieval-Augmented Generation) assistant that provides detailed answers regarding stock market performance in 2024 by querying a specific PDF document. The agent’s purpose is to minimize hallucinations using a deterministic model (llama3-70b-8192 with temperature 0) and a ChromaDB vector store for high-fidelity information retrieval. The data flow is managed through a StateGraph where the process begins at the llm node, which determines if a user's query requires external knowledge. If tool calls are identified, the graph transitions via a conditional edge to the retriever_agent node to execute the retriever_tool, which extracts relevant document chunks using similarity search. The resulting data is then fed back into the llm node to synthesize a final response with citations, continuing this loop until the model provides a terminal answer without further tool requirements.

        ## Tools
        - `extract_pdf_text`
- `perform_similarity_search`
- `synthesize_response_with_citations`

        ## Usage
        ```bash
        cd output/stock_market_rag_assistant
        export OPENAI_API_KEY=your_key_here
        python run.py "Your query here"
        ```

        ## Fingerprint
        `N/A`
