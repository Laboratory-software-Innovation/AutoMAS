        # travel_assistant

        An AI agent for: This agent is designed as a travel and transportation assistant that facilitates ride inquiries, bookings, and flight searches through a structured tool-calling loop. The agent’s core purpose is to manage user travel requests by interfacing with a fare table for ground transportation and external APIs for flight information. The data flow starts at the agent node, where the LLM processes the user’s message history to determine if a specific tool—such as Get_ride_details, Book_ride, or Get_flight—is required. If a function call is identified, the graph transitions to the action node via the continue path, where the tool_executor invokes the relevant function and returns the results to the conversation state. This loop repeats until the model provides a final Response or no further function calls are needed, at which point the graph reaches the end state and delivers the consolidated information to the user.

        ## Tools
        - `get_ride_details`
- `book_ride`
- `get_flight`

        ## Usage
        ```bash
        cd output/travel_assistant
        export OPENAI_API_KEY=your_key_here
        python run.py "Your query here"
        ```

        ## Fingerprint
        `N/A`
