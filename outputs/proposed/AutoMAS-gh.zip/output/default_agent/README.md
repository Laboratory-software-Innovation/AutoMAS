        # default_agent

        An AI agent for: 

        ## Tools
        - `fetch_current_weather`
- `fetch_weather_forecast`
- `parse_weather_data`

        ## Usage
        ```bash
        cd output/default_agent
        export OPENAI_API_KEY=your_key_here
        python run.py "Your query here"
        ```

        ## Fingerprint
        `N/A`
