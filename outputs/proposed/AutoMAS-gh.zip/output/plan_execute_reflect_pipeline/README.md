        # plan_execute_reflect_pipeline

        An AI agent for: This agent is designed as an iterative task-solving pipeline that uses a "Plan-Execute-Reflect" loop to address complex user queries. The data flow begins at the planner node, which decomposes the initial query into a structured, numbered list of actionable tasks. The graph then transitions to the executor node, where it processes the current task by referencing the history of previously executed steps and results to maintain context. Following execution, the reflector node assesses the progress and output to determine if the remaining plan requires modification, addition, or deletion of tasks based on real-world feedback or failures. The process utilizes conditional edges to either loop back to the executor for the next task or terminate once the reflection results in a "DONE" status or the maximum revision limit is reached, ensuring a state-aware, self-correcting workflow.

        ## Tools
        - `task_execution_tool`
- `reflection_tool`

        ## Usage
        ```bash
        cd output/plan_execute_reflect_pipeline
        export OPENAI_API_KEY=your_key_here
        python run.py "Your query here"
        ```

        ## Fingerprint
        `N/A`
