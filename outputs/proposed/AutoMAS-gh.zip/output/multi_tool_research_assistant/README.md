        # multi_tool_research_assistant

        An AI agent for: This agent is designed as a multi-tool research assistant that utilizes an OpenAI functions agent to dynamically select and execute tools based on user queries. The data flow begins at the agent node, where the gpt-4o-mini model processes the input and agent state to determine whether to call a specific tool—such as Wikipedia for factual lookups, OpenWeatherMap for local weather, or Tavily for general internet searches—or provide a final answer. If a tool is required, the graph transitions to the action node via a conditional edge, where the ToolNode executes the requested function and appends the result to the intermediate steps. The workflow then loops back to the agent node to evaluate the tool output and decide if further actions are needed or if the process should terminate at the END node with a final response.

        ## Tools
        - `wikipedia_lookup`
- `fetch_local_weather`
- `perform_internet_search`

        ## Usage
        ```bash
        cd output/multi_tool_research_assistant
        export OPENAI_API_KEY=your_key_here
        python run.py "Your query here"
        ```

        ## Fingerprint
        `N/A`
