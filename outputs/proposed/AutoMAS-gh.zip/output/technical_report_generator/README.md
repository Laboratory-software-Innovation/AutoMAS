# technical_report_generator

An AI agent for: This agent is designed as an automated technical analyst that transforms raw text into a structured technical report using an agentic RAG workflow. The data flow begins with the load_text and adaptive_chunking nodes, which ingest a transcript and split it into topic-based semantic chunks for better retrieval. After indexing these chunks into a ChromaDB vector store via the create_retriever node, the graph proceeds to determine_report_structure, where an LLM generates a table of contents to guide the report's creation. The process then enters a state-aware loop through the generate_section node, which retrieves relevant context for each identified topic and generates factual content, specifically flagging any sections with insufficient context for human review. Finally, once all sections are processed via the should_continue conditional edge, the compile_report node assembles the individual sections and review notices into a single Markdown file, completing the document generation lifecycle.

## Tools
- `generate_table_of_contents`

## Usage
```bash
cd output/technical_report_generator
export OPENAI_API_KEY=your_key_here
python run.py "Your query here"
```

## Fingerprint
`N/A`
