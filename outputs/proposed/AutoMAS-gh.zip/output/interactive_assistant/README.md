        # interactive_assistant

        An AI agent for: This agent is an interactive assistant designed to execute external functions through tool-calling while maintaining persistent conversation state. The data flow initiates at the chatbot node, where a Qwen 2.5 language model processes incoming user messages; a conditional router then evaluates the output, directing the flow to a tools node for executing the simple_screener function if tool calls are detected, or to the END node if the response is complete. By looping tool outputs back to the chatbot and utilizing an InMemorySaver for checkpointing, the graph ensures that the agent can perform multi-step reasoning and retain context across sequential user prompts within a specified thread.

        ## Tools
        - `process_user_message`
- `execute_simple_screener`
- `loop_tool_output_to_chatbot`
- `update_conversation_context`

        ## Usage
        ```bash
        cd output/interactive_assistant
        export OPENAI_API_KEY=your_key_here
        python run.py "Your query here"
        ```

        ## Fingerprint
        `N/A`
