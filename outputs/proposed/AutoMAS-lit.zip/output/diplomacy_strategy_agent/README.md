        # diplomacy_strategy_agent

        An AI agent for: The Azure OpenAI Agent Module implements a specialized LLM-driven agent designed to play the strategy game Diplomacy. Its core intent is to automate decision-making by processing game states—including unit deployments, supply center ownership, and seasonal phase information—to generate strategic action commands. The data flow begins with the extraction of current game metrics from the Diplomacy game engine, which are then formatted into a prompt using a predefined template. This structured data is passed to the AzureChatOpenAI model via a LangChain LLMChain to generate a response. Finally, the agent parses the model's text output into executable game orders and determines the active status of powers based on units and centers across different game phases.

        ## Tools
        - `game_state_extraction_tool`
- `azure_chat_openai_tool`
- `order_parser_tool`
- `power_status_determiner_tool`

        ## Usage
        ```bash
        cd output/diplomacy_strategy_agent
        export OPENAI_API_KEY=your_key_here
        python run.py "Your query here"
        ```

        ## Fingerprint
        `N/A`
