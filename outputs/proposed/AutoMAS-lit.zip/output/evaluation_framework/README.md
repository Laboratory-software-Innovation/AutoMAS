        # evaluation_framework

        An AI agent for: The code implements an evaluation framework designed to assess the accuracy of SRAgent predictions by comparing them against ground truth metadata stored in a PostgreSQL database. Its core purpose is to facilitate the ingestion of evaluation datasets, query predicted and actual metadata, and generate detailed accuracy reports across multiple categories. Information flows from CSV files or database tables into a central processing logic that joins experimental results with reference data, identifies discrepancies, and outputs performance metrics and mismatch records to the console and external files for further analysis.

        ## Tools
        - `csv_reader`
- `database_connector`
- `sql_executor`
- `compare_metadata`
- `generate_accuracy_report`

        ## Usage
        ```bash
        cd output/evaluation_framework
        export OPENAI_API_KEY=your_key_here
        python run.py "Your query here"
        ```

        ## Fingerprint
        `N/A`
