        # compro_scanner_pipeline

        An AI agent for: The ComProScanner class implements an automated pipeline for extracting material composition and property data from scientific literature through a four-step modular flow. Its core intent is to transform unstructured paper metadata into a high-fidelity structured dataset by first discovering and filtering article metadata from various publishers, then pre-processing text into a RAG-enabled vector database. The data flow moves from metadata discovery to an orchestrator-led multi-agent extraction phase, where raw text is processed into structured result dictionaries, and concludes with a post-processing stage that validates chemical elements and resolves numerical fractions to ensure data integrity.

        ## Tools
        - `metadata_search_tool`
- `text_cleaning_tool`
- `vector_db_ingestion_tool`
- `chemical_element_validation_tool`
- `numerical_fraction_resolution_tool`

        ## Usage
        ```bash
        cd output/compro_scanner_pipeline
        export OPENAI_API_KEY=your_key_here
        python run.py "Your query here"
        ```

        ## Fingerprint
        `N/A`
